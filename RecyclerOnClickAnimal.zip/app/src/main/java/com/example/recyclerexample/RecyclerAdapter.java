package com.example.recyclerexample;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ImageViewHolder>
{

    private  int[] m_images;
    private String[] m_texts = {"פרה","תרנגולת","כלב","חמור","סוס","אריה","פיל","כבשה","קוף","חתול"};
    private Context m_context;
    //Ctor
    public RecyclerAdapter(int[] images, Context context)
    {
        m_images = images;
        m_context=context;
    }

    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.album_layout,parent,false);
       ImageViewHolder imageViewHolder = new ImageViewHolder(view,m_context,m_images);
       return  imageViewHolder;
    }

    @Override
    public void onBindViewHolder( ImageViewHolder holder, int position)
    {
     int image_id = m_images[position];
     holder.m_album_image.setImageResource(image_id);//טעינת התמונות לholder
     holder.m_album_title.setText(m_texts[position]);//טעינת הטקסט לholder

    }

    @Override
    public int getItemCount() {
        return m_images.length;
    }

    //-------------------------------------------------------------
    public static class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        ImageView m_album_image;
        TextView m_album_title;
        Context m_context;
        int[] m_images;

        public ImageViewHolder(@NonNull View itemView,Context context,int[] images)
        {
            super(itemView);
            m_album_image = itemView.findViewById(R.id.Image1);
            m_album_title = itemView.findViewById(R.id.Text1);
            itemView.setOnClickListener(this);
            m_context=context;
            m_images= images;



        }

        @Override
        public void onClick(View v)
        {
            Intent intent = new Intent(m_context,DisplayActivity.class);
            intent.putExtra("image_id",m_images[getAdapterPosition()]);
            m_context.startActivity(intent);

        }
    }
}
