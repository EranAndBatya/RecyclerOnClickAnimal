package com.example.recyclerexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class DisplayActivity extends AppCompatActivity {

    ImageView m_imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        m_imageView= findViewById(R.id.album_display);
        m_imageView.setImageResource(getIntent().getIntExtra("image_id",00));

    }
}
